# README

## 1. wasmtime

To obtain GitHub bug reports in wasmtime, run the following command: 

```shell
curl >wasmtime_github_bug_reports.json 'https://api.github.com/repos/bytecodealliance/wasmtime/issues?state=closed&labels=bug&sort=created'
```

## 2. wasmer

To obtain GitHub bug reports in wasmer, run the following command: 

```shell
curl >wasmer_github_bug_reports.json 'https://api.github.com/repos/wasmerio/wasmer/issues?state=closed&labels=bug&sort=created'
```

## 3. WAMR

```shell
curl >WAMR_github_bug_reports.json 'https://api.github.com/repos/bytecodealliance/wasm-micro-runtime/issues?state=closed&sort=created'
```

## 4. Wasmer-python

```shell
curl >wasmer_python_github_bug_reports.json 'https://api.github.com/repos/wasmerio/wasmer-python/issues?labels=%F0%9F%90%9E%20bug&state=closed&sort=created'
```

## 5. Wasmer-go

```shell
curl >wasmer_go_github_bug_reports.json 'https://api.github.com/repos/wasmerio/wasmer-go/issues?labels=%F0%9F%90%9E%20bug&state=closed'
```

## 6. wasm3
```shell
curl >wasm3_github_bug_reports.json 'https://api.github.com/repos/wasm3/wasm3/issues?labels=bug&state=closed&sort=created'
```

## 7. WasmEdge
```shell
curl >WasmEdge_github_bug_reports.json 'https://api.github.com/repos/WasmEdge/WasmEdge/issues?labels=bug&state=closed&sort=created'
```