# [A.2]-1

## Test target
This test case is to test whether a wasm runtime could output same result when using differnent level of optimization.

## Steps to use
Use cli to execute the `x` function in the wat file.

## Expected output
2648111804832205941349218734877573630