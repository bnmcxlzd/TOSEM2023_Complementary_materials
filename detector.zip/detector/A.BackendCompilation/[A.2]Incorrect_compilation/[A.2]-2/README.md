# [A.2]-2

## Test target
This test case is to test whether a wasm runtime could emit correct native code for `f32x4.abs` and `v128.not` instructions in wasm.

## Steps to use
Use cli or high-level language api to execute the func1 in the wasm or wat file.

## Expected output
340282366920938463463374607431768211455