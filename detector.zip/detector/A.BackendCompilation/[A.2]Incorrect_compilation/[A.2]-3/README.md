# [A.2]-3

## Test target
This test case is to test whether a wasm runtime could correctly pass the static data to the host functions.

## Steps to use
Use high-level language api to execute.

## Expected output
Print_input_host 6513249
equals i32 !
Print_input_host 1819043176
equals i32 !
Print_input_host 1819043176
Print_input_host 1685024583
Print_input_host 1685024583
Print_input_host 3355185