#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "wasm_c_api.h"

#define own

// Print a Wasm value
void wasm_val_print(wasm_val_t val) {
    switch (val.kind) {
        case WASM_I32: {
            printf("%" PRIu32, val.of.i32);
        } break;
        case WASM_I64: {
            printf("%" PRIu64, val.of.i64);
        } break;
        case WASM_F32: {
            printf("%f", val.of.f32);
        } break;
        case WASM_F64: {
            printf("%g", val.of.f64);
        } break;
        case WASM_ANYREF:
        case WASM_FUNCREF: {
            if (val.of.ref == NULL) {
                printf("null");
            } else {
                printf("ref(%p)", val.of.ref);
            }
        } break;
    }
}

own wasm_trap_t* print_input(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    printf("Print_intput_host ");
    wasm_val_print(args->data[0]);
    printf("\n");

//    wasm_val_copy(&results->data[0], &args->data[0]);
    return NULL;
}

own wasm_trap_t* assert_eq_i32(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    int x = (args->data[0]).of.i32;
    int y = (args->data[1]).of.i32;

    if(x == y){
        printf("equals i32 !\n");
    }else{
        printf("Not equals i32 !\n");
    }

    return NULL;
}



int main(int argc, const char* argv[]) {
    // Initialize.
    printf("Initializing...\n");
    wasm_engine_t* engine = wasm_engine_new();
    wasm_store_t* store = wasm_store_new(engine);

    // Load binary.
    printf("Loading binary...\n");
#if WASM_ENABLE_AOT != 0 && WASM_ENABLE_INTERP == 0
    FILE* file = fopen("test-A2-3.aot", "rb");
#else
    FILE* file = fopen("test-A2-3.wasm", "rb");
#endif
    if (!file) {
        printf("> Error loading module!\n");
        return 1;
    }

    int ret = fseek(file, 0L, SEEK_END);
    if (ret == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    long file_size = ftell(file);
    if (file_size == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    ret = fseek(file, 0L, SEEK_SET);
    if (ret == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    wasm_byte_vec_t binary;
    wasm_byte_vec_new_uninitialized(&binary, file_size);
    if (fread(binary.data, file_size, 1, file) != 1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }
    fclose(file);

    // Compile.
    printf("Compiling module...\n");
    own wasm_module_t* module = wasm_module_new(store, &binary);
    if (!module) {
        printf("> Error compiling module!\n");
        return 1;
    }

    wasm_byte_vec_delete(&binary);

    // Create external print functions.
    printf("Creating callback...\n");

    own wasm_functype_t* func1_type = wasm_functype_new_1_0(wasm_valtype_new_i32());
    own wasm_func_t* func1 = wasm_func_new(store, func1_type, print_input);

    own wasm_functype_t* func2_type = wasm_functype_new_2_0(wasm_valtype_new_i32(), wasm_valtype_new_i32());
    own wasm_func_t* func2 = wasm_func_new(store, func2_type, assert_eq_i32);


    wasm_functype_delete(func1_type);
    wasm_functype_delete(func2_type);

    // Instantiate.
    printf("Instantiating module...\n");
    wasm_extern_t* externs[] = {
        wasm_func_as_extern(func2), wasm_func_as_extern(func1)
    };


    wasm_extern_vec_t imports = WASM_ARRAY_VEC(externs);
    own wasm_instance_t* instance =
        wasm_instance_new(store, module, &imports, NULL);
    if (!instance) {
        printf("> Error instantiating module!\n");
        return 1;
    }

    wasm_func_delete(func1);
    wasm_func_delete(func2);


    // Shut down.
    printf("Shutting down...\n");
    wasm_store_delete(store);
    wasm_engine_delete(engine);

    // All done.
    printf("Done.\n");
    return 0;
}