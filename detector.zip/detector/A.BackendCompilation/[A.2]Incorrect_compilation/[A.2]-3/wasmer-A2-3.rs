

use wasmer::{imports, wat2wasm, Function, Instance, Module, NativeFunc, Store, Value};

// compiler
use wasmer_compiler_cranelift::Cranelift;
use wasmer_compiler_singlepass::Singlepass;
use wasmer_compiler_llvm::LLVM;

// engine
use wasmer_engine_universal::Universal;

use std::fs::File;
use std::io::Read;

fn main() -> anyhow::Result<()> {


    let wasm_bytes = wat2wasm(
        r#"
(module
  (import "env" "assert_eq_i32" (func $assert_eq_i32 (param i32 i32)))
  (import "env" "print_input" (func $print_input (param i32)))

  (memory 1)
  (data 0 (offset (i32.const 0)) "abc")
  (data 0 (offset (i32.const 100)) "hello")
  (data 0 (offset (i32.const 1000)) "Good morning !")
  (data 0 (offset (i32.const 2400)) "123")

  (start $main)
  (func $main (export "main")
    (call $print_input (i32.load offset=0 (i32.const 0)))

    (call $assert_eq_i32 (i32.load offset=100 (i32.const 0)) (i32.const 0x6C6C_6568))
    (call $print_input (i32.load offset=100 (i32.const 0)))

    (call $assert_eq_i32 (i32.load offset=0 (i32.const 100)) (i32.const 0x6C6C_6568))
    (call $print_input (i32.load offset=0 (i32.const 100)))

    (call $print_input (i32.load offset=0 (i32.const 1000)))

    (call $print_input (i32.load offset=1000 (i32.const 0)))

    (call $print_input (i32.load offset=1000 (i32.const 1400)))
  )
)
"#
            .as_bytes(),
    )?;


    let store = Store::new(&Universal::new(Singlepass::default()).engine());
    let module = Module::new(&store, wasm_bytes)?;


    fn print_input_host(x:i32){
        println!("Print_input_host {0}", x);
        // println!(*x)
    }

    fn assert_eq_i32_host(x:i32, y:i32){
        if(x == y){
            println!("equals i32 !");
        }else{
            println!("Not equals i32 !");
        }
    }


    let import_object = imports! {
        // We use the default namespace "env".
        "env" => {
            // And call our function "say_hello".
            "print_input" => Function::new_native(&store, print_input_host),
            "assert_eq_i32" => Function::new_native(&store, assert_eq_i32_host),
        },
    };


    let instance = Instance::new(&module, &import_object)?;

    let func1 = instance.exports.get_function("main")?;

    Ok(())
}

#[test]
fn test_hello_world() -> anyhow::Result<()> {
    main()
}
