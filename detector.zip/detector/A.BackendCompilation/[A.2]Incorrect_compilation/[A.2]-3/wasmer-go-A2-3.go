package main

import (
	"fmt"
	"github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {
    wasmBytes, _ := ioutil.ReadFile("./A2-3.wasm")

    engine := wasmer.NewEngine()
    store := wasmer.NewStore(engine)

    // Compiles the module
    module, err := wasmer.NewModule(store, wasmBytes)

    if err != nil {
        fmt.Println("Failed to compile module:", err)
    }

	fmt.Println("Creating the imported function...")
    type MyEnvironment struct{}

	environment := MyEnvironment{}
	assert_eq := func(environment interface{}, args []wasmer.Value) ([]wasmer.Value, error) {
		if args[0]==args[1] {
            fmt.Println("equals i32 !")
        }else{
            fmt.Println("Not equals i32 !")
        }
        return []wasmer.Value{}, nil
	}
	assert_eq_i32 := wasmer.NewFunctionWithEnvironment(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.I32, wasmer.I32), wasmer.NewValueTypes()),
		environment,
		assert_eq,
	)

    environment2 := MyEnvironment{}
	print_in := func(environment interface{}, args []wasmer.Value) ([]wasmer.Value, error) {
		fmt.Println("Print_input_host ", args[0])
        return []wasmer.Value{}, nil
	}
	print_input := wasmer.NewFunctionWithEnvironment(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.I32), wasmer.NewValueTypes()),
		environment2,
		print_in,
	)
	

    // Instantiates the module
    importObject := wasmer.NewImportObject()
    importObject.Register(
		"env",
		map[string]wasmer.IntoExtern{
			"assert_eq_i32": assert_eq_i32,
			"print_input":  print_input,
		},
	)

    instance, err := wasmer.NewInstance(module, importObject)

    if err != nil {
        panic(fmt.Sprintln("Failed to instantiate the module:", err))
    }

    

    func1, err := instance.Exports.GetFunction("main")
    if err != nil {
	    panic(fmt.Sprintln("Failed to get the `main` function:", err))
    }

    result, err := func1()

    if err != nil {
        panic(fmt.Sprintln("Failed to call the `main` function:", err))
    }
    
    fmt.Println(result)

}