import os
from wasmer import engine, wat2wasm, Store, Module, ImportObject, Function, FunctionType, Type, Instance
from wasmer_compiler_cranelift import Compiler



# Create a store.
store = Store(engine.Universal(Compiler))

# Let's compile the Wasm module.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../A2-3.wasm', 'rb').read())

import_object = ImportObject()

def print_input(x: int):
    print("Print_input_host ", x)

def assert_eq_i32(x: int, y: int):
    if x==y:
        print("equals i32 !")
    else:
        print("Not equals i32 !")

print_input_host = Function(store, print_input)
assert_eq_i32_host = Function(store, assert_eq_i32)


def print_input(x):
    print("Print_input_host ", x)

def assert_eq_i32(x, y):
    if x==y:
        print("equals i32 !")
    else:
        print("Not equals i32 !")

print_input_host = Function(
    store,
    print_input,
    FunctionType([Type.I32], [])
)

assert_eq_i32_host = Function(
    store,
    assert_eq_i32,
    FunctionType([Type.I32, Type.I32], [])
)



# Now let's register the `sum` import inside the `env` namespace.
import_object.register(
    "env",
    {
        "print_input": print_input_host,
        "assert_eq_i32": assert_eq_i32_host,
    }
)

# Let's instantiate the module!
instance = Instance(module, import_object)

