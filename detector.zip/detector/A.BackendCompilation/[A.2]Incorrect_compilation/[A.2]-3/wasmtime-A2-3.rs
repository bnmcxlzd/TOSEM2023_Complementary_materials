//! Small example of how to instantiate a wasm module that imports one function,
//! showing how you can fill in host functionality for a wasm module.

// cargo run -q --example test-A2-3

use anyhow::Result;
use wasmtime::*;


fn main() -> Result<()> {
    // Modules can be compiled through either the text or binary format
    let engine = Engine::default();
    let module = Module::from_file(&engine, "./A2-3.wat")?;


    let mut linker = Linker::new(&engine);
    linker.func_wrap("env", "print_input", |caller: Caller<'_, u32>, x: i32| {
        println!("Print_input_host {0}", x);
    })?;
    linker.func_wrap("env", "assert_eq_i32", |caller: Caller<'_, u32>, x: i32, y: i32| {
        if(x == y){
            println!("equals i32 !");
        }else{
            println!("Not equals i32 !");
        }
    })?;


    let mut store = Store::new(&engine, 4);
    let instance = linker.instantiate(&mut store, &module)?;

    Ok(())
}

