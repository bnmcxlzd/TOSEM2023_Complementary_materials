# [A.2]-4

## Test target
This test case is to test whether a wasm runtime could successfully compile the wasm or wat file with multivalue.

## Steps to use
Use cli or high-level language api to load the module in the wasm or wat file.

## Expected output
Successfully load the module.
