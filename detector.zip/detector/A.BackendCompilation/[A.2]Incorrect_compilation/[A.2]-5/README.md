# [A.2]-5

## Test target
This test case is to test whether a wasm runtime could correctly compile the `rotr` instruction in wasm or wat file.

## Steps to use
Use cli or high-level language api to execute the _main function in the wasm or wat file.

## Expected output
4
