import os

from wasmer import engine, wat2wasm, Store, Module, Instance
from wasmer_compiler_cranelift import Compiler
# from wasmer_compiler_llvm import Compiler
# from wasmer_compiler_singlepass import Compiler

engine = engine.Universal(Compiler)

# Create a store, that holds the engine.
store = Store(engine)

# Let's compile the Wasm module with the Cranelift compiler.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../A2-6.wasm', 'rb').read())

# Let's instantiate the Wasm module.
instance = Instance(module)

# Let's call the `sum` exported function.
func1 = instance.exports.multiply_4
results = func1()

print(results)

func1 = instance.exports.multiply_8
results = func1()

print(results)