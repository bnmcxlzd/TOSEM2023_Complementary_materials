# [A.3]-1

## Test target
 This test case is to test whether a Wasm runtime could correctly execute the `select` instruction with two v128 parameters in the Wasm binaries with SIMD instructions.

## Steps to use
Use cli or high-level language api to execute the func1 in the wasm or wat file.

## Expected output
79228162514264337593543950336
