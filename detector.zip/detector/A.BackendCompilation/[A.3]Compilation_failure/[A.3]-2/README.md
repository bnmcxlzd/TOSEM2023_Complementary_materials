# [A.3]-2

## Test target
This test case is to test whether a wasm runtime could correctly compile the module with simd lowering.
Executing in x64 hardware could be better.

## Steps to use
Use cli or high-level language api to load the module in the wat or wasm file.

## Expected output
Successfully load the module.
