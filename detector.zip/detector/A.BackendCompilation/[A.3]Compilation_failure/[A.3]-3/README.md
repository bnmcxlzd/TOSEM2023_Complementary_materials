# [A.3]-4

## Test target
This test case is to test whether a wasm runtime could successfully compile the wasm or wat file.
This wasm file is a Go database(TiDB).

## Steps to use
Use cli or high-level language api to execute the wasm file.

## Expected output
TiDB [pingcap]>