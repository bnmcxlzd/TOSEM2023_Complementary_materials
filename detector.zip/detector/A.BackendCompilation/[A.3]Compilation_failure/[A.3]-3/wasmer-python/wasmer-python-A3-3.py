import os

from wasmer import engine, wat2wasm, Store, Module, Instance, wasi
# from wasmer_compiler_cranelift import Compiler
# from wasmer_compiler_llvm import Compiler
from wasmer_compiler_singlepass import Compiler

engine = engine.Universal(Compiler)

# Create a store, that holds the engine.
store = Store(engine)

# Let's compile the Wasm module with the Cranelift compiler.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../A3-3.wasm', 'rb').read())

# Get the WASI version.
wasi_version = wasi.get_version(module, strict=True)

# Build a WASI environment for the imports.
wasi_env = wasi.StateBuilder('test-program').argument('--foo').finalize()

# Generate an `ImportObject` from the WASI environment.
import_object = wasi_env.generate_import_object(store, wasi_version)

# Now we are ready to instantiate the module.
instance = Instance(module, import_object)

# instance = Instance(module)

# Here we go, let's start the program.
instance.exports._start()

