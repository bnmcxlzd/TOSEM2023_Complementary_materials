# [A.4]-1

## Test target
This test case is to test whether a wasm runtime could successfully load the wasm or wat file with SIMD instructions.

## Steps to use
Use cli or high-level language api to execute the func1 in the wasm or wat file.

## Expected output
Successfully load the module and execute the `func1`.