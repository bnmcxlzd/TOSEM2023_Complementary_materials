# [A.7]-1

## Test target
This test case is to test whether a wasm runtime could correctly execute the simd instructions in the wat or wasm file.

## Steps to use
Use cli or high-level language api to execute the `_start` function in the wat or wasm file.

## Expected output
0
