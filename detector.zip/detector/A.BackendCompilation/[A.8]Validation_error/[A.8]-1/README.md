# [A.8]-1

## Test target
This test case is to test whether a wasm runtime could set the max value of memory in wasm.

## Steps to use
Use cli or high-level language api to load the module in the wasm or wat file.

## Expected output
Successfully load the module and set the max value of memory.
