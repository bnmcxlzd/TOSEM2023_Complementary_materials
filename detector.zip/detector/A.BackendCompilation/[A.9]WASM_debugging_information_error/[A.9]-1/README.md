# [A.9]-1

## Test target
This test case is to test whether a wasm runtime could correctly compile the wasm or wat file.

## Steps to use
Use cli or high-level language api to execute the _start function in the wasm or wat file.

## Expected output
Successfully execute the `_start` function in the wasm or wat file and print nothing.