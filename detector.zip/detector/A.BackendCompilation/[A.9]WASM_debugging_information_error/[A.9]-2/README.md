# [A.9]-2

## Test target
This test case is to test whether a wasm runtime could correctly compile the wasm or wat file.

## Steps to use
Use cli or high-level language api to execute the `main` function in the wasm or wat file.

## Expected output
65
