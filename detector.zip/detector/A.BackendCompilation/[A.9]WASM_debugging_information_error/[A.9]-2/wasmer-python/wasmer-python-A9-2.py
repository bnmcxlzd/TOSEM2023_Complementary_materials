import os

from wasmer import engine, wat2wasm, Store, Module, Instance, wasi
from wasmer_compiler_cranelift import Compiler
# from wasmer_compiler_llvm import Compiler
# from wasmer_compiler_singlepass import Compiler

engine = engine.Universal(Compiler)

# Create a store, that holds the engine.
store = Store(engine)

# Let's compile the Wasm module with the Cranelift compiler.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../A9-2.wasm', 'rb').read())


instance = Instance(module)

# Let's call the `sum` exported function.
func1 = instance.exports.main
results = func1()

print(results)