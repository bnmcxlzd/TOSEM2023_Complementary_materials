# [B.1]-1
 
## Test target
Tests whether the `rename` function returns an error


## Steps to use
```shell
# jit
# wasmer linux|windows|macos
wasmer run --mapdir=/scratch:scratch B1-1.wasm
# wasmtime linux|windows|macos
wasmtime --mapdir=/scratch::scratch B1-1.wasm  
# wamr linux|windows|macos
iwasm --dir=scratch/ B1-1.wasm

# aot
# wasmer linux|windows|macos
wasmer compile B1-1.wasm -o B1-1-cranelift.wasm --cranelift
wasmer compile B1-1.wasm -o B1-1-singlepass.wasm --singlepass
wasmer run --mapdir=/scratch::scratch B1-1-cranelift.wasm
wasmer run --mapdir=/scratch::scratch B1-1-singlepass.wasm
# wasmtime
wasmtime compile B1-1.wasm
wasmtime run --allow-precompiled --mapdir=/scratch::scratch B1-1.cwasm
# wamr
wamrc -o B1-1-wamr.aot B1-1.wasm
iwasm --dir=scratch/ B1-1-wamr.aot
```

`
# wasm3
wasm3 --dir=scratch/ B1-1.wasm

# wasmedge 
wasmedge --dir=scratch/ B1-1.wasm
wasmedgec B1-1.wasm B1-1.so
wasmedge --dir=scratch/ B1-1.so
`

## Expected output
Change the filename of oldfile in scratch directory to newfile
