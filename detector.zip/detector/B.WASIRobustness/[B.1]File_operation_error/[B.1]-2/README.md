# [B.1]-2
 
## Test target
Test for error in rename file operation.


## Steps to use
```shell
# jit
# wasmer linux|windows|macos
wasmer run --dir=./dir uutils.wasm -- mv dir/foo dir/bar
# wasmtime linux|windows|macos
wasmtime --dir=./dir uutils.wasm -- mv dir/foo dir/bar 
# wamr
iwasm --dir=./dir uutils.wasm  mv dir/foo dir/bar

# aot
# wasmer linux|windows|macos
wasmer compile uutils.wasm -o uutils-cranelift.wasm --cranelift
wasmer compile uutils.wasm -o uutils-singlepass.wasm --singlepass
wasmer run --dir=./dir uutils-cranelift.wasm -- mv dir/foo dir/bar
wasmer --dir=./dir uutils-singlepass.wasm -- mv dir/foo dir/bar 
# wasmtime linux|windows|macos
wasmtime compile uutils.wasm
wasmtime run --allow-precompiled --dir=./dir uutils.cwasm -- mv dir/foo dir/bar 
# wamr
wamrc -o uutils-wamr.aot uutils.wasm
iwasm --dir=./dir uutils-wamr.aot  mv dir/foo dir/bar

```

wasm3
`wasm3 --dir=./dir uutils.wasm mv dir/foo dir/bar`

wasmedge
`wasmedge --dir=./dir uutils.wasm mv dir/foo dir/bar` or
`wasmedgec uutils.wasm uutils.so` `wasmedge --dir=./dir uutils.so mv dir/foo dir/bar`

## Expected output
Change the filename of foo in dir directory to bar
