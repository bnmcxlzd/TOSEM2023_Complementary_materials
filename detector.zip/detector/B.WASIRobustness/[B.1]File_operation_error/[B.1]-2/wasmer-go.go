package main

import (
	"fmt"
	wasmer "github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {

	// os.Chdir(filepath.Dir(os.Args[0]))

    wasmBytes, _ := ioutil.ReadFile("./uutils.wasm")

    store := wasmer.NewStore(wasmer.NewEngine())

	module, _ := wasmer.NewModule(store, wasmBytes)

    wasiEnv, _ := wasmer.NewWasiStateBuilder("uutils").
		// Choose according to your actual situation
		Argument("mv dir/foo dir/bar").
		// Environment("ABC", "DEF").
		MapDirectory("./dir", "./dir").
		Finalize()
	if store == nil {
		fmt.Println("store is null")
	}
	if module == nil {
		fmt.Println("module is null")
	}
	importObject, err := wasiEnv.GenerateImportObject(store, module)
	check(err)

	instance, err := wasmer.NewInstance(module, importObject)
	check(err)

	start, err := instance.Exports.GetWasiStartFunction()
	check(err)
	start()

}

func check(e error) {
	if e != nil {
		panic(e)
	}
}