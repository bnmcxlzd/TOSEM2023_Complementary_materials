from wasmer import wasi, Store, ImportObject, Module, Instance
import os
import subprocess
import sys

def run():
    store = Store()
    module = Module(store, open('uutils.wasm', 'rb').read())

    wasi_version = wasi.get_version(module, strict=True)

    # Build a WASI environment for the imports.
    wasi_env = wasi.StateBuilder('--dir=./dir').argument('mv dir/foo dir/bar').finalize()

    # Generate an `ImportObject` from the WASI environment.
    import_object = wasi_env.generate_import_object(store, wasi_version)

    # Now we are ready to instantiate the module.
    instance = Instance(module, import_object)

    instance.exports._start()


    # file = open("uutils.wasm", "rb").read()
    
    # store = Store()
    # wasi_env = wasi.StateBuilder("--dir=./dir").argument("mv dir/foo dir/bar").finalize()
    # import_object = wasi_env.generate_import_object(store, wasi.Version.LATEST)

    # instance = Instance(Module(store, file), import_object)
    # instance.exports._start()

    # func1 = instance.exports._start
    # results = func1()

    # print(results)


if __name__=="__main__":
    # Print the current working directory
    print("Current working directory: {0}".format(os.getcwd()))
    os.chdir(os.path.split(os.path.realpath(__file__))[0])
    print("Current working directory: {0}".format(os.getcwd()))
    run()