#include <errno.h>
#include <stdio.h>

int main() {
  printf("ENOENT: %d\n", ENOENT);
  printf("EINVAL: %d\n", EINVAL);

  int r = rename("doesnotexist.txt", "doesnotexistagain.txt");
  printf("r: %d\n", r);
  printf("errno: %d\n", errno);
  perror("rename() error");
}