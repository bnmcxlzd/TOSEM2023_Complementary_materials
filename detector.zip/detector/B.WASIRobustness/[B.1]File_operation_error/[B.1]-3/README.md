# [B.1]-3

## Test target
Tests whether renaming a nonexistent file is inconsistent with the POSIX API


## Steps to use
```shell
# wasmer linux|windows|macos
wasmer run --dir=. B1-3.wasm
# wasmtime linux|windows|macos
wasmtime --dir=. B1-3.wasm
# wamr
iwasm --dir=. B1-3.wasm

# aot
# wasmer linux|windows|macos
wasmer compile B1-3.wasm -o B1-3-cranelift.wasm --cranelift   
wasmer compile B1-3wasm -o B1-3-singlepass.wasm --singlepass
wasmer run --dir=. B1-3-cranelift.wasm
wasmer run --dir=. B1-3-singlepass.wasm
# wasmtime
wasmtime compile B1-3.wasm
wasmtime run --allow-precompiled --dir=. B1-3.cwasm
# wamr
wamrc -o B1-3-wamr.aot B1-3.wasm
iwasm --dir=. B1-3-wamr.aot
```

wasm3
`wasm3 --dir=. B1-3.wasm`

wasmedge
`wasmedge --dir=. B1-3.wasm` or
`wasmedgec B1-3.wasm B1-3.so` and `wasmedge --dir=. B1-3.so`

## Expected output
Print following:
```
ENOENT: 44
EINVAL: 28
r: -1
errno: 44
rename() error: No such file or directory
```