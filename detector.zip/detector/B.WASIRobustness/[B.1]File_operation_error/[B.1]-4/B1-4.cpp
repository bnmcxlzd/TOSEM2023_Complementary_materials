#include <dirent.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char **argv) {
  DIR *d;

  char * target = ".";
  if (argc == 2) {
      target = argv[1];
  }
  struct dirent *dir;
  d = opendir(target);
  if (d) {
    while ((dir = readdir(d)) != NULL) {
      printf("%s\n", dir->d_name);
    }

    printf("errno: %d\n", errno);
    closedir(d);
  }

  return(0);
}