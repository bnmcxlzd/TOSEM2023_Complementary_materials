# [B.1]-4

## Test target
Tests the readdir function for errors

## Steps to use
```shell
bash generate-files.sh 200

# wasmer linux|macos
wasmer run B1-4.wasm --dir=./testfolder -- testfolder | wc -l
# wasmer windows
wasmer run B1-4.wasm --dir=./testfolder -- testfolder | Measure-Object -Line
# wasmtime linux|macos
wasmtime B1-4.wasm --dir=./testfolder -- testfolder | wc -l
# wasmtime windows
wasmtime B1-4.wasm --dir=./testfolder -- testfolder | Measure-Object -Line
# wamr linux|macos
iwasm --dir=./testfolder B1-4.wasm testfolder | wc -l
# wamr windows
iwasm B1-4.wasm --dir=./testfolder -- testfolder | Measure-Object -Line

# aot
# wasmer linux|macos
wasmer compile B1-4.wasm -o B1-4-cranelift.wasm --cranelift
wasmer compile B1-4.wasm -o B1-4-singlepass.wasm --singlepass
wasmer run --dir=./testfolder B1-4-cranelift.wasm -- testfolder | wc -l
wasmer run --dir=./testfolder B1-4-singlepass.wasm -- testfolder | wc -l
# wasmer windows
wasmer run --dir=./testfolder B1-4-cranelift.wasm -- testfolder | Measure-Object -Line
wasmer run --dir=./testfolder B1-4-singlepass.wasm -- testfolder | Measure-Object -Line
# wasmtime linux|macos
wasmtime compile B1-4.wasm
wasmtime run --allow-precompiled --dir=./testfolder B1-4.cwasm -- testfolder | wc -l
# wasmtime windows
wasmtime run --allow-precompiled --dir=./testfolder B1-4.cwasm -- testfolder | Measure-Object -Line
# wamr
wamrc -o B1-4-wamr.aot B1-4.wasm
iwasm --dir=./testfolder B1-4-wamr.aot testfolder | wc -l
# wamr windows
iwasm --dir=./testfolder B1-4-wamr.aot -- testfolder | Measure-Object 
```
```

wasm3
wasm3 B1-4.wasm --dir=./testfolder -- testfolder | wc -l

wasmedge
wasmedge --dir=testfolder B1-4.wasm testfolder | wc -l
or 
wasmedgec B1-4.wasm B1-4.so
wasmedge --dir=testfolder B1-4.so testfolder | wc -l





## Expected output
Print following：
```
203
```
