fn main() -> std::io::Result<()> {
	for entry in std::fs::read_dir("/")? {
		println!("{}", entry?.path().display());
	}
	Ok(())
}