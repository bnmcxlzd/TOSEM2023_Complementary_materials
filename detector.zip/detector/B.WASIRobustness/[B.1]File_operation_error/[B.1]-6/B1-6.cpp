#include <fstream>

int main() {
	std::ofstream ff;
	ff.open("test.txt", std::ofstream::trunc);
	ff << "1\n";
	return 0;
}