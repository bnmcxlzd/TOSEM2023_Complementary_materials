# [B.1]-6
 
## Test target
Test for problems with the Trunc function implementation

## Steps to use
```shell
# wasmer linux|macos|windows
wasmer run --dir=. B1-6.wasm
# wasmtime linux|macos|windows
wasmtime --dir=. B1-6.wasm
# wamr linux|macos|windows
iwasm --dir=. B1-6.wasm
# wasm3 
wasm3 --dir=. B1-6.wasm
# wasmedge 
wasmedge --dir=. B1-6.wasm

# aot
# wasmer linux|windows|macos
wasmer compile B1-6.wasm -o B1-6-cranelift.wasm --cranelift
wasmer compile B1-6.wasm -o B1-6-singlepass.wasm --singlepass
wasmer run --dir=. B1-6-cranelift.wasm
wasmer run --dir=. B1-6-singlepass.wasm
# wasmtime
wasmtime compile B1-6.wasm
wasmtime run --allow-precompiled --dir=. B1-6.cwasm
# wamr
wamrc -o B1-6-wamr.aot B1-6.wasm
iwasm --dir=. B1-6-wamr.aot
# wasmedge 
wasmedgec B1-6.wasm B1-6.so
wasmedge --dir=. B1-6.so
```

## Expected output
The file content is truncated