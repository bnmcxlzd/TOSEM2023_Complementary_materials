#include<cstdio>

int add(int a, int b){
    return a + b;
}

int main(){
    int a = 1, b = 2;
    a = add(a, b);
    printf("hello world!\n"); 
}