# [B.2]-1

## Test target
Test whether importing multiple wasi versions produces errors.

## Steps to use
```shell
# wasmer linux|windows|macos
wasmer run B2-1.wasm --allow-multiple-wasi-versions
# wasmtime linux|windows|macos
wasmtime B2-1.wasm
# wamr linux|windows|macos
iwasm B2-1.wasm 

# aot
# wasmer linux|windows|macos
wasmer compile B2-1.wasm -o B2-1-cranelift.wasm --cranelift
wasmer compile B2-1.wasm -o B2-1-singlepass.wasm --singlepass
wasmer run B2-1-cranelift.wasm --allow-multiple-wasi-versions
wasmer run B2-1-singlepass.wasm --allow-multiple-wasi-versions
# wasmtime
wasmtime compile B2-1.wasm
wasmtime run --allow-precompiled B2-1.cwasm
# wamr
wamrc -o B2-1-wamr.aot B2-1.wasm
iwasm B2-1-wamr.aot
```



wasm3
wasm3 B2-1.wasm

WasmEdge
wasmedge B2-1.wasm


## Expected output
Execute correctly without error and output the following.
```
hello world!
```