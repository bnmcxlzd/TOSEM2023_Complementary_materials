from wasmer import wasi, Store, ImportObject, Module, Instance
import os
import subprocess
import sys

def run():
    file = open("B2-1.wasm", "rb").read()
    
    store = Store()
    wasi_env = wasi.StateBuilder("B2-1").finalize()

    wasi_version = wasi.get_version(Module(store, file), strict=True)
    import_object = wasi_env.generate_import_object(store, wasi.Version.LATEST)

    instance = Instance(Module(store, file), import_object)
    instance.exports._start()


if __name__=="__main__":
    # Print the current working directory
    print("Current working directory: {0}".format(os.getcwd()))
    os.chdir(os.path.split(os.path.realpath(__file__))[0])
    print("Current working directory: {0}".format(os.getcwd()))
    run()
    """
    The B2-1.wasm runs well, when i use the command "wasmer run B2-1.wasm --allow-multiple-wasi-versions".
    However, the wasmer-python seems not support multiple wasi versions, and it has the following errors:
        RuntimeError: Error while importing "wasi_unstable"."fd_write": unknown import. Expected Function(FunctionType { params: [I32, I32, I32, I32], results: [I32] })
    """
    