# [B.3]-1
 
## Test target
Verify that `fd_write` and `fd_read` of WASI fail when the right edge of the buffer overlaps with the right edge of memory.

## Steps to use
```shell
# wasmer linux|macos|windows
wasmer run B3-1.wasm
# wasmtime linux|macos|windows
wasmtime  B3-1.wasm
# wamr linux|macos|windows
iwasm B3-1.wasm
```

# aot
# wasmer linux|windows|macos
wasmer compile B3-1.wasm -o B3-1-cranelift.wasm --cranelift
wasmer compile B3-1.wasm -o B3-1-singlepass.wasm --singlepass
wasmer run B3-1-cranelift.wasm
wasmer run B3-1-singlepass.wasm
# wasmtime
wasmtime compile B3-1.wasm
wasmtime run --allow-precompiled B3-1.cwasm
# wamr
wamrc -o B3-1-wamr.aot B3-1.wasm
iwasm B3-1-wamr.aot

# wasm3
wasm3 B3-1.wasm

# wasmedge
wasmedge B3-1.wasm
or
wasmedgec B3-1.wasm B3-1.so
wasmedge B3-1.so

## Expected output
Print following:
```
TEST
```