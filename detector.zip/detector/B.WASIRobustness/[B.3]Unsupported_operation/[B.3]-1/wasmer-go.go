package main

import (
	"fmt"
	wasmer "github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {

	// os.Chdir(filepath.Dir(os.Args[0]))

    wasmBytes, _ := ioutil.ReadFile("./B3-1.wasm")

    store := wasmer.NewStore(wasmer.NewEngine())

	module, _ := wasmer.NewModule(store, wasmBytes)

    wasiEnv, _ := wasmer.NewWasiStateBuilder("test").
		// Choose according to your actual situation
		// Environment("ABC", "DEF").
		Finalize()
	if store == nil {
		fmt.Println("store is null")
	}
	if module == nil {
		fmt.Println("module is null")
	}
	importObject, err := wasiEnv.GenerateImportObject(store, module)
	check(err)

	instance, err := wasmer.NewInstance(module, importObject)
	check(err)

	start, err := instance.Exports.GetWasiStartFunction()
	check(err)
	start()

}

func check(e error) {
	if e != nil {
		panic(e)
	}
}