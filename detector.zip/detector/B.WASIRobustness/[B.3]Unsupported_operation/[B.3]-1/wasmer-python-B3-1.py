from wasmer import wasi, Store, ImportObject, Module, Instance
import os
import subprocess
import sys

def run():
    file = open("B3-1.wasm", "rb").read()
    
    store = Store()
    wasi_env = wasi.StateBuilder("B3-1").finalize()
    import_object = wasi_env.generate_import_object(store, wasi.Version.LATEST)

    instance = Instance(Module(store, file), import_object)
    instance.exports._start()



if __name__=="__main__":
    # Print the current working directory
    print("Current working directory: {0}".format(os.getcwd()))
    os.chdir(os.path.split(os.path.realpath(__file__))[0])
    print("Current working directory: {0}".format(os.getcwd()))
    run()
    # When i execute this program, it outputs following errors:
    """
    Traceback (most recent call last):
        File "/home/wasm/runtime-evaluation/zhangyixuan/detector/B.WASIRobustness/[B.3]Unsupported_operation/[B.3]-1/wasmer-py.py", line 22, in <module>
            run()
        File "/home/wasm/runtime-evaluation/zhangyixuan/detector/B.WASIRobustness/[B.3]Unsupported_operation/[B.3]-1/wasmer-py.py", line 14, in run
            instance.exports._start()
        RuntimeError: RuntimeError: WASI exited with code: 0
    """