# [B.4]-1

## Test target
Tests `Stdin`, `Stdout`, `Stderr` for missing an implementation of `filestat_get`.

## Steps to use
```shell
# wasmer linux|windows|macos
wasmer run B4-1.wasm
# wasmtime linux|windows|macos
wasmtime B4-1.wasm
# wamr
iwasm B4-1.wasm
```

# aot
# wasmer linux|windows|macos
wasmer compile B4-1.wasm -o B4-1-cranelift.wasm --cranelift
wasmer compile B4-1.wasm -o B4-1-singlepass.wasm --singlepass
wasmer run B4-1-cranelift.wasm
wasmer run B4-1-singlepass.wasm
# wasmtime
wasmtime compile B4-1.wasm
wasmtime run --allow-precompiled B4-1.cwasm
# wamr
wamrc -o B4-1-wamr.aot B4-1.wasm
iwasm B4-1-wamr.aot

wasm3
wasm3 B4-1.wasm

wasmedge
wasmedge B4-1.wasm

## Expected output
Execution without error.
__wasi_fd_fdstat_get for stdout: 0
rights for stdout: 136314954
type for stdout: 2
has filestat_get rights for stdout: yes
__wasi_fd_filestat_get for stdout: 0
fstat for stdout (fd: 1): 0

