from wasmer import wasi, Store, ImportObject, Module, Instance
import os
import subprocess
import sys

def run():
    file = open("B4-1.wasm", "rb").read()
    
    store = Store()
    wasi_env = wasi.StateBuilder("B4-1").finalize()
    import_object = wasi_env.generate_import_object(store, wasi.Version.LATEST)

    instance = Instance(Module(store, file), import_object)
    instance.exports._start()


if __name__=="__main__":
    # Print the current working directory
    print("Current working directory: {0}".format(os.getcwd()))
    os.chdir(os.path.split(os.path.realpath(__file__))[0])
    print("Current working directory: {0}".format(os.getcwd()))
    run()
    # The output is different from the one in README.md, and the output of wasmtime cli is different too.