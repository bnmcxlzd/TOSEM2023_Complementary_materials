# [B.5]-1
 
## Test target
Test for problems with the `Wasi_poll_oneoff` implementation

## Steps to use
```shell
# wasmer linux|macos|windows
wasmer run B5-1.wasm
# wasmtime linux|macos|windows
wasmtime B5-1.wasm
# wamr linux|macos|windows
iwasm --stack-size=102400 B5-1.wasm
# wasm3
wasm3 B5-1.wasm
# wasmedge
wasmedge B5-1.wasm

# aot
# wasmer linux|windows|macos
wasmer compile B5-1.wasm -o B5-1-cranelift.wasm --cranelift
wasmer compile B5-1.wasm -o B5-1-singlepass.wasm --singlepass
wasmer run B5-1-cranelift.wasm
wasmer run B5-1-singlepass.wasm
# wasmtime
wasmtime compile B5-1.wasm
wasmtime run --allow-precompiled B5-1.cwasm
# wamr
wamrc -o B5-1-wamr.aot B5-1.wasm
iwasm B5-1-wamr.aot
# wasmedge
wasmedgec B5-1.wasm B5-1.so
wasmedge B5-1.so

and input `console.log(new Date())` qjs command to test the execution.

```


## Expected output
Normal execution of the QuickJS engine produces no errors.

