# [C.10]-1
 
## Test target
Tests whether performing an unsupported function correctly outputs an error message instead of causing panic.

## Steps to use
```shell
# jit
# wasmer linux|macos|windows
wasmer run demo.wasm 
# wasmtime linux|macos|windows
wasmtime run --wasm-features=all demo.wasm
# wamr linux|macos
iwasm demo.wasm 
# wamr windows
iwasm demo.wasm 
# wasm3 windows
wasm3 demo.wasm 
# wasmedge windows
wasmedge demo.wasm or 
wasmedgec demo.wasm demo.so wasmedge demo.so


#aot
# wasmer linux|macos|windows
wasmer compile demo.wasm  -o demo-cranelift.wasm --cranelift
wasmer compile demo.wasm  -o demo-singlepass.wasm --singlepass
wasmer run demo-cranelift.wasm 
wasmer run demo-singlepass.wasm 
# wasmtime linux|macos|windows
wasmtime compile demo.wasm
wasmtime run --allow-precompiled --wasm-features=all  demo.cwasm
# wamr linux|macos|windows
wamrc -o demo-wamr.wasm demo.wasm
iwasm demo-wamr.wasm 
```

## Expected output
It doesn't cause panic.

