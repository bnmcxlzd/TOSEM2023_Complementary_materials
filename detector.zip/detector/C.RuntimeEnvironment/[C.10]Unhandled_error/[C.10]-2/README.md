# [C.10]-2
 
## Test target
An overlength data section is probably worth a runtime error, but it shouldn't be an assertion failure.

## Steps to use
```shell
# jit
# wasmer linux|macos|windows
wasmer run demo.wasm 
# wasmtime linux|macos|windows
wasmtime run demo.wasm
# wamr linux|macos|windows
iwasm demo.wasm 
# wasm3 windows
wasm3 demo.wasm 
# wasmedge windows
wasmedge demo.wasm 


#aot
# wasmer linux|macos|windows
wasmer compile demo.wasm  -o demo-cranelift.wasm --cranelift
wasmer compile demo.wasm  -o demo-singlepass.wasm --singlepass
wasmer run demo-cranelift.wasm 
wasmer run demo-singlepass.wasm 
# wasmtime linux|macos|windows
wasmtime compile demo.wasm
wasmtime run --allow-precompiled demo.cwasm
# wamr linux|macos|windows
wamrc -o demo-wamr.wasm demo.wasm
iwasm demo-wamr.wasm 
```

## Expected output
Output the runtime error.