# [C.10]-3
 
## Test target
Tests whether performing an unsupported function correctly outputs an error message instead of causing panic.

## Steps to use
```shell
# jit
# wasmer linux|macos|windows
wasmer run demo.wasm -i fib abc
# wasmtime linux|macos|windows
wasmtime run demo.wasm --invoke 'fib' abc
# wamr linux|macos|windows
iwasm -f fib demo.wasm abc
# wasm3 windows
wasm3 --func fib demo.wasm abc
# wasmedge windows
wasmedge --reactor demo.wasm fib abc or 
wasmedgec demo.wasm demo.so
wasmedge --reactor demo.so fib abc or

#aot
# wasmer linux|macos|windows
wasmer compile demo.wasm  -o demo-cranelift.wasm --cranelift
wasmer compile demo.wasm  -o demo-singlepass.wasm --singlepass
wasmer run demo-cranelift.wasm -i fib  -- abc
wasmer run demo-singlepass.wasm -i fib  -- abc
# wasmtime linux|macos|windows
wasmtime compile demo.wasm
wasmtime run --allow-precompiled demo.cwasm --invoke 'fib' abc
# wamr linux|macos|windows
wamrc -o demo-wamr.wasm demo.wasm
iwasm -f fib demo-wamr.wasm abc
```

## Expected output
It doesn't cause panic.