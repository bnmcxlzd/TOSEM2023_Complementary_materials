
#include <stdio.h>
#include <string.h>
#include <wasmedge/wasmedge.h>

int main() {
  /* Create the configure context and add the WASI support. */
  /* This step is not necessary unless you need WASI support. */
  WasmEdge_ConfigureContext *ConfCxt = WasmEdge_ConfigureCreate();
  WasmEdge_ConfigureAddHostRegistration(ConfCxt, WasmEdge_HostRegistration_Wasi);

  /* The configure and store context to the VM creation can be NULL. */
  WasmEdge_VMContext *VMCxt = WasmEdge_VMCreate(ConfCxt, NULL);


  /* Create the import object. */
  WasmEdge_String importName = WasmEdge_StringCreateByCString("env");
  WasmEdge_ImportObjectContext *ImpObj = WasmEdge_ImportObjectCreate(importName);
  WasmEdge_StringDelete(importName);


  WasmEdge_VMRegisterModuleFromImport(VMCxt, ImpObj);

  /* Function name. */
//  WasmEdge_String FuncName = WasmEdge_StringCreateByCString("main");

  /* Run the WASM function from file. */
  //WasmEdge_String FuncName1 = WasmEdge_StringCreateByCString("print_input");
  WasmEdge_String FuncName = NULL;
  WasmEdge_Result Res = WasmEdge_VMRunWasmFromFile(VMCxt, "C1-1.wasm", FuncName, NULL, 0, NULL, 0);

  if (WasmEdge_ResultOK(Res)) {
    printf("Successfully executed !");
  } else {
    printf("Error !");
  }

  /* Resources deallocations. */
  WasmEdge_VMDelete(VMCxt);
  WasmEdge_ConfigureDelete(ConfCxt);
//  WasmEdge_StringDelete(FuncName);
  return 0;
}
