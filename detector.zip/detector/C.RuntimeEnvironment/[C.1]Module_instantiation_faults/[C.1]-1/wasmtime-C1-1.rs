// cargo run -q --example test-C1-1

use anyhow::Result;
use wasmtime::*;

struct MyState {
    name: String,
    count: usize,
}

fn main() -> Result<()> {
    println!("========== Start test ==========");

    println!("Compiling module...");
    let engine = Engine::default();
    let wat = r#"
(module
    (memory (export "memory") 100)
    (data (i32.const 0) "Hello World!")
)"#;
    let module = Module::new(&engine, wat)?;
    //let module = Module::from_file(&engine, "benchmark/taxonomy/RuntimeEnvironment/test-wasmtime2784.wat")?;

    println!("Initializing...");
    let mut store = Store::new(
        &engine,
        MyState {
            name: "test-wasmtime3337".to_string(),
            count: 0,
        },
    );

    println!("Instantiating module...");
    let imports = [];
    let instance = Instance::new(&mut store, &module, &imports)?;


    println!("========== Finish test ==========");
    Ok(())

}