# [C.1]-2

## Test target
This test case is to test whether a wasm runtime could instantiate a module.
And execute the `sum `function in the module.

## Steps to use
Use high-level language api to load the module and execute the `sum` function.
Repeat this in a loop.

## Expected output
Successfully load the module without memory exhaustion.