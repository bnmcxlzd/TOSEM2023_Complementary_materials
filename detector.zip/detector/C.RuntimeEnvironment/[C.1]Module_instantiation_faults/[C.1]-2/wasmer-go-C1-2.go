package main

import (
	"fmt"
	"github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {
    wasmBytes, _ := ioutil.ReadFile("./C1-2.wasm")

    for {
        engine := wasmer.NewEngine()
        store := wasmer.NewStore(engine)
    
        // Compiles the module
        module, err := wasmer.NewModule(store, wasmBytes)
    
        if err != nil {
            fmt.Println("Failed to compile module:", err)
        }
    
        importObject := wasmer.NewImportObject()
        instance, err := wasmer.NewInstance(module, importObject)
    
        if err != nil {
            panic(fmt.Sprintln("Failed to instantiate the module:", err))
        }
    
    
        func1, err := instance.Exports.GetFunction("sum")
        if err != nil {
            panic(fmt.Sprintln("Failed to get the `sum` function:", err))
        }
    
        result, err := func1(1, 2)
        fmt.Println(result)
    }
}