# [C.1]-3

## Test target
This test case is to test whether a wasm runtime could instantiate an empty module.

## Steps to use
Use high-level language api to load the module.

## Expected output
Successfully load the module.