
#include <stdio.h>
#include <string.h>
#include <wasmedge/wasmedge.h>


int main() {
  /* Create the configure context and add the WASI support. */
  /* This step is not necessary unless you need WASI support. */
  WasmEdge_ConfigureContext *ConfCxt = WasmEdge_ConfigureCreate();
  WasmEdge_ConfigureAddHostRegistration(ConfCxt, WasmEdge_HostRegistration_Wasi);

  /* The configure and store context to the VM creation can be NULL. */
  WasmEdge_VMContext *VMCxt = WasmEdge_VMCreate(ConfCxt, NULL);


  /* Function name. */
  WasmEdge_String FuncName = WasmEdge_StringCreateByCString("sum");

  /* Run the WASM function from file. */
  WasmEdge_Value Params[2] = { WasmEdge_ValueGenI32(3), WasmEdge_ValueGenI32(6) };
  WasmEdge_Value Returns[1];
  WasmEdge_Result Res = WasmEdge_VMRunWasmFromFile(VMCxt, "C1-3.wasm", FuncName, Params, 2, Returns, 1);

  if (WasmEdge_ResultOK(Res)) {
    printf("Get the result: %d\n", WasmEdge_ValueGetI32(Returns[0]));
  } else {
    printf("Error message: %s\n", WasmEdge_ResultGetMessage(Res));
  }

  /* Resources deallocations. */
  WasmEdge_VMDelete(VMCxt);
  WasmEdge_ConfigureDelete(ConfCxt);
  WasmEdge_StringDelete(FuncName);

  return 0;
}
