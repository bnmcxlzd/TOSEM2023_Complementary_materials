// cargo run --example test-C1-3

use wasm3::{Environment, WasmArg};
use wasm3::Module;

fn main() {
    println!("Start testing ...");

    let env = Environment::new().expect("Unable to create environment");
    let rt = env
        .create_runtime(1024 * 60)
        .expect("Unable to create runtime");
    let module = Module::parse(&env, &include_bytes!("../../taxonomy/RuntimeEnvironment/C1-3.wasm")[..])
        .expect("Unable to parse module");

    let module = rt.load_module(module).expect("Unable to load module");

    println!("Finish testing ...");
}