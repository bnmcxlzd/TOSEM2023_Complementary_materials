//! This is a simple example introducing the core concepts of the Wasmer API.
//!
//! You can run the example directly by executing the following in the Wasmer root:
//!
//! ```
//! cargo run -q --example test-C1-3 --release --features "singlepass,cranelift,llvm,wasi"
//! ```

use wasmer::{imports, wat2wasm, Function, Instance, Module, NativeFunc, Store, Value};

// compiler
use wasmer_compiler_cranelift::Cranelift;
use wasmer_compiler_singlepass::Singlepass;
use wasmer_compiler_llvm::LLVM;


// engine
use wasmer_engine_universal::Universal;

use std::fs::File;
use std::io::Read;

fn main() -> anyhow::Result<()> {
    println!("========== Start test ==========");

    // read wat file as bytes
    let mut f = File::open("benchmark/taxonomy/RuntimeEnvironment/C1-3.wat").unwrap();
    let mut buf = Vec::new();
    f.read_to_end(&mut buf).unwrap();

    let wasm_bytes = wat2wasm(buf.as_slice()).unwrap();

    // specify compiler and engine
    let store = Store::new(&Universal::new(Cranelift::default()).engine());
    //let store = Store::new(&Universal::new(LLVM::default()).engine());
    //let store = Store::new(&Universal::new(Singlepass::default()).engine());


    println!("Compiling module...");
    let module = Module::new(&store, wasm_bytes)?;

    println!("Instantiating module imports...");
    let import_object = {};
    let instance = Instance::new(&module, &import_object)?;


    println!("========== Finish test ==========");
    Ok(())
}

#[test]
fn test() -> anyhow::Result<()> {
    main()
}
