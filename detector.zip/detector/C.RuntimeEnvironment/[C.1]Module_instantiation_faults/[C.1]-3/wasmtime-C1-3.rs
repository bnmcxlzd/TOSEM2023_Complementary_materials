//! Small example of how to instantiate a wasm module that imports one function,
//! showing how you can fill in host functionality for a wasm module.

// cargo run -q --example test-C1-3

use anyhow::Result;
use wasmtime::*;

struct MyState {
    name: String,
    count: usize,
}

fn main() -> Result<()> {
    println!("========== Start test ==========");

    println!("Compiling module...");
    let engine = Engine::default();
    let module = Module::from_file(&engine, "benchmark/taxonomy/RuntimeEnvironment/C1-3.wat")?;

    println!("Initializing...");
    let mut store = Store::new(
        &engine,
        MyState {
            name: "test".to_string(),
            count: 0,
        },
    );



    println!("Instantiating module...");
    let imports = [];
    let instance = Instance::new(&mut store, &module, &imports)?;

    println!("========== Finish test ==========");
    Ok(())
}
