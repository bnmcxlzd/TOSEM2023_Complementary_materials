# [C.2]-1

## Test target
This test case is to test whether a wasm runtime could deal with the error of `index out of bounds` errors when import_global_index is greeter than imports.globals length.

## Steps to use
Use cli or high-level language api to load and execute the module.

## Expected output
Report error without panic.