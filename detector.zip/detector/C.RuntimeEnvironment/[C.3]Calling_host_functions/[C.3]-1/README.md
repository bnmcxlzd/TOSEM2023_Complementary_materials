# [C.3-1]

## Test target
This test case is to test whether a wasm runtime could import host functions from self-defined module, not only `env`.

## Steps to use
Use high-level language api load and execute the module.

## Expected output
sum_i32_host Results: 3
sum_i32_host Results: 1819017217
sum_i32_host Results: 2124157492