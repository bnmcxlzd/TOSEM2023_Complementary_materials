#include <stdio.h>
#include <string.h>
#include <wasmedge/wasmedge.h>


WasmEdge_Result sum_host(void *Data, WasmEdge_MemoryInstanceContext *MemCxt,const WasmEdge_Value *In, WasmEdge_Value *Out) {
  int32_t Val1 = WasmEdge_ValueGetI32(In[0]);
  int32_t Val2 = WasmEdge_ValueGetI32(In[1]);
  int32_t Val3 = Val1 + Val2;
  printf("sum_i32_host Results: %d\n", Val3);

  /* Return the status of success. */
  return WasmEdge_Result_Success;
}


int main() {
  /* Create the configure context and add the WASI support. */
  /* This step is not necessary unless you need WASI support. */
  WasmEdge_ConfigureContext *ConfCxt = WasmEdge_ConfigureCreate();
//  WasmEdge_ConfigureAddHostRegistration(ConfCxt, WasmEdge_HostRegistration_Wasi);

  /* The configure and store context to the VM creation can be NULL. */
  WasmEdge_VMContext *VMCxt = WasmEdge_VMCreate(ConfCxt, NULL);


  /* Create the import object. */
  WasmEdge_String importName = WasmEdge_StringCreateByCString("myenv");
  WasmEdge_ImportObjectContext *ImpObj = WasmEdge_ImportObjectCreate(importName);
  WasmEdge_StringDelete(importName);

  // import host functions
  enum WasmEdge_ValType Param[2];
  Param[0] = WasmEdge_ValType_I32;
  Param[1] = WasmEdge_ValType_I32;
  WasmEdge_FunctionTypeContext *HostFType = NULL;
  HostFType = WasmEdge_FunctionTypeCreate(Param, 2, NULL, 0);
  WasmEdge_FunctionInstanceContext *HostFunc = WasmEdge_FunctionInstanceCreate(HostFType, sum_host, NULL, 0);
  WasmEdge_FunctionTypeDelete(HostFType);

  WasmEdge_String FuncName = WasmEdge_StringCreateByCString("sum_i32");
  WasmEdge_ImportObjectAddFunction(ImpObj, FuncName, HostFunc);
  WasmEdge_StringDelete(FuncName);

  WasmEdge_VMRegisterModuleFromImport(VMCxt, ImpObj);

  /* Function name. */
  FuncName = WasmEdge_StringCreateByCString("test");

  /* Run the WASM function from file. */
  WasmEdge_Result Res = WasmEdge_VMRunWasmFromFile(VMCxt, "C3-1.wasm", FuncName, NULL, 0, NULL, 0);


  /* Resources deallocations. */
  WasmEdge_FunctionInstanceDelete(HostFunc);
  WasmEdge_VMDelete(VMCxt);
  WasmEdge_ConfigureDelete(ConfCxt);
  WasmEdge_StringDelete(FuncName);
  return 0;
}
