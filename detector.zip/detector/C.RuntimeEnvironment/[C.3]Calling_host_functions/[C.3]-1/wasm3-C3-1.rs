// cargo run --example test-C3-1

use wasm3::{Environment, WasmArg};
use wasm3::Module;

fn main() {
    println!("Start testing ...");

    let env = Environment::new().expect("Unable to create environment");
    let rt = env
        .create_runtime(1024 * 60)
        .expect("Unable to create runtime");
    let module = Module::parse(&env, &include_bytes!("../../taxonomy/RuntimeEnvironment/C3-1.wasm")[..])
        .expect("Unable to parse module");

    let mut module = rt.load_module(module).expect("Unable to load module");
    module
        .link_function::<(i32, i32), ()>("myenv", "sum_i32", sum_host)
        .expect("Unable to link function");
    let func = module
        .find_function::<(), ()>("test")
        .expect("Unable to find function");
    func.call();

    // println!("{}ms in seconds is {:?}s.", MILLIS, func.call());
    // assert_eq!(func.call(), Ok(MILLIS / 1000));

    println!("Finish testing ...");
}

wasm3::make_func_wrapper!(sum_host: sum(x:u32 , y:u32));
fn sum(x:u32 , y:u32) {
    let s = x + y;
    println!("sum_i32_host Results: {:?}", s);
}