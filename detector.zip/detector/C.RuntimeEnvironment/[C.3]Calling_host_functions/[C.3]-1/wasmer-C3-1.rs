//! This is a simple example introducing the core concepts of the Wasmer API.
//!
//! You can run the example directly by executing the following in the Wasmer root:
//!
//! ```shell
//! cargo run --example test-C3-1 --release --features "singlepass,cranelift,llvm,wasi"
//! ```

use wasmer::{imports, wat2wasm, Function, Instance, Module, NativeFunc, Store, Value};

// compiler
use wasmer_compiler_cranelift::Cranelift;
use wasmer_compiler_singlepass::Singlepass;
use wasmer_compiler_llvm::LLVM;

// engine
use wasmer_engine_universal::Universal;

use std::fs::File;
use std::io::Read;

fn main() -> anyhow::Result<()> {
    //read wat file as bytes
    // let mut f = File::open("benchmark/taxonomy/BackendCompilation/test-wasmer2721.wat").unwrap();
    // let mut buf = Vec::new();
    // f.read_to_end(&mut buf).unwrap();
    // let wasm_bytes = wat2wasm(buf.as_slice()).unwrap().as_bytes();

    let wasm_bytes = wat2wasm(
        r#"
(module
  (import "myenv" "sum_i32" (func $sum_i32 (param i32 i32)))

  (func $test (export "test")
    (call $sum_i32 (i32.const 0x1) (i32.const 0x2))
    (call $sum_i32 (i32.const 0x6C6C_0000) (i32.const 0x1))
    (call $sum_i32 (i32.const 0x6C6C_1234) (i32.const 0x1230_0000))
  )
)
"#
            .as_bytes(),
    )?;


    let store = Store::new(&Universal::new(Cranelift::default()).engine());
    let module = Module::new(&store, wasm_bytes)?;

    fn sum_i32_host(x:i32, y:i32){
        let s = x + y;
        println!("sum_i32_host Results: {:?}", s);
    }


    let import_object = imports! {
        // We use the default namespace "env".
        "myenv" => {
            "sum_i32" => Function::new_native(&store, sum_i32_host),
        },
    };


    let instance = Instance::new(&module, &import_object)?; //有start部分，load instance之后会自动执行start

    let func1 = instance.exports.get_function("test")?;
    let results = func1.call(&[])?;
    // println!("Results: {:?}", results);

    Ok(())
}

#[test]
fn test_hello_world() -> anyhow::Result<()> {
    main()
}
