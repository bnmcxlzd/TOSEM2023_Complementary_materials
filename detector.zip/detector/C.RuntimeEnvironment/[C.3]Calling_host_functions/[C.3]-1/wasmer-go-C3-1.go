package main

import (
	"fmt"
	"github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {
    wasmBytes, _ := ioutil.ReadFile("./C3-1.wasm")

    engine := wasmer.NewEngine()
    store := wasmer.NewStore(engine)

    // Compiles the module
    module, err := wasmer.NewModule(store, wasmBytes)

    if err != nil {
        fmt.Println("Failed to compile module:", err)
    }

	fmt.Println("Creating the imported function...")
	
    sum_i32 := wasmer.NewFunction(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.I32, wasmer.I32), wasmer.NewValueTypes()),
		func(args []wasmer.Value) ([]wasmer.Value, error) {
            res := args[0].I32() + args[1].I32()
            fmt.Println("sum_i32_host Results: ", res);
			return []wasmer.Value{}, nil
		},
	)

    // Instantiates the module
    importObject := wasmer.NewImportObject()
    importObject.Register(
		"myenv",
		map[string]wasmer.IntoExtern{
			"sum_i32": sum_i32,
		},
	)

    instance, err := wasmer.NewInstance(module, importObject)

    if err != nil {
        panic(fmt.Sprintln("Failed to instantiate the module:", err))
    }
    

    func1, err := instance.Exports.GetFunction("test")
    if err != nil {
	    panic(fmt.Sprintln("Failed to get the `test` function:", err))
    }

    result, err := func1()

    if err != nil {
        panic(fmt.Sprintln("Failed to call the `test` function:", err))
    }
    
    fmt.Println(result)
}