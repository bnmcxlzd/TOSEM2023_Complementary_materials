import os
from wasmer import engine, wat2wasm, Store, Module, ImportObject, Function, FunctionType, Type, Instance
from wasmer_compiler_cranelift import Compiler


# Create a store.
store = Store(engine.Universal(Compiler))

# Let's compile the Wasm module.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../C3-1.wasm', 'rb').read())

import_object = ImportObject()

# Let's write the Python function that is going to be imported,
# i.e. called by the WebAssembly module.
def sum32_i32(x: int, y:int):
    r = x + y
    print("sum_i32_host Results: ", r)

sum32_i32_host = Function(store, sum32_i32)


def sum32_i32(x, y):
    r = x + y
    print("sum_i32_host Results: ", r)

sum32_i32_host = Function(
    store,
    sum32_i32,
    FunctionType([Type.I32, Type.I32], [])
)


import_object.register(
    "myenv",
    {
        "sum_i32": sum32_i32_host,
    }
)

# Let's instantiate the module!
instance = Instance(module, import_object)

func1 = instance.exports.test
results = func1()

print(results)