//! Small example of how to instantiate a wasm module that imports one function,
//! showing how you can fill in host functionality for a wasm module.

// cargo run -q --example test-C3-1

use anyhow::Result;
use wasmtime::*;


fn main() -> Result<()> {
    // Modules can be compiled through either the text or binary format
    let engine = Engine::default();
    let module = Module::from_file(&engine, "benchmark/taxonomy/RuntimeEnvironment/C3-1.wat")?;

    // let module;
    // unsafe{
    //     module = Module::deserialize(&engine, "benchmark/taxonomy/BackendCompilation/C3-1.cwasm")?;
    // }



    let mut linker = Linker::new(&engine);
    linker.func_wrap("myenv", "sum_i32", |caller: Caller<'_, u32>, x: i32, y: i32| {
        let s = x + y;
        println!("sum_i32_host Results: {:?}", s);
    })?;


    let mut store = Store::new(&engine, 4);
    let instance = linker.instantiate(&mut store, &module)?;

    println!("Extracting export...");
    let func1 = instance.get_typed_func::<(), (), _>(&mut store, "test")?;

    println!("Calling func1...");
    func1.call(&mut store, ())?;

    Ok(())
}

