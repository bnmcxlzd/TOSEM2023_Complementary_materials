# [C.4]-1

## Test target
This test case is to test whether a wasm runtime could allocate the memory of 0, and grow the memory.

## Steps to use
（1）Use high-level language api to load the `C4-1.wat` and execute the `func1` function.
（2）Use high-level language api to load the `C4-1-memory_test.wat` and execute the `func2` function.

## Expected output
（1）
equals i32 !
equals i32 !
equals i32 !
equals i32 !
（2）
equals i32 !
equals i32 !
Not equals i32 !
Not equals i32 !
equals i32 !
equals i32 !
equals i64 !
equals f32 !
equals f64 !
equals i64 !
equals i64 !
equals i64 !
equals i32 !
equals i32 !
equals i32 !
equals i32 !
equals i64 !
equals i64 !
equals i64 !
