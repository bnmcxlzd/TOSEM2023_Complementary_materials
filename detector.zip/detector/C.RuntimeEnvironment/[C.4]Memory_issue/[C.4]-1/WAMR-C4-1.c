#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "wasm_c_api.h"

#define own


own wasm_trap_t* assert_eq_i32(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    int x = (args->data[0]).of.i32;
    int y = (args->data[1]).of.i32;

    if(x == y){
        printf("equals i32 !\n");
    }else{
        printf("Not equals i32 !\n");
    }

    return NULL;
}

own wasm_trap_t* assert_eq_i64(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    int x = (args->data[0]).of.i64;
    int y = (args->data[1]).of.i64;

    if(x == y){
        printf("equals i64 !\n");
    }else{
        printf("Not equals i64 !\n");
    };

    return NULL;
}

own wasm_trap_t* assert_eq_f32(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    int x = (args->data[0]).of.f32;
    int y = (args->data[1]).of.f32;

    if(x == y){
        printf("equals f32 !\n");
    }else{
        printf("Not equals f32 !\n");
    }

    return NULL;
}

own wasm_trap_t* assert_eq_f64(
    const wasm_val_vec_t* args, wasm_val_vec_t* results
) {
    int x = (args->data[0]).of.f64;
    int y = (args->data[1]).of.f64;

    if(x == y){
        printf("equals f64 !\n");
    }else{
        printf("Not equals f64 !\n");
    }

    return NULL;
}



int main(int argc, const char* argv[]) {
    // Initialize.
    // printf("Initializing...\n");
    wasm_engine_t* engine = wasm_engine_new();
    wasm_store_t* store = wasm_store_new(engine);

    // Load binary.
    // printf("Loading binary...\n");
#if WASM_ENABLE_AOT != 0 && WASM_ENABLE_INTERP == 0
    FILE* file = fopen("C4-1.aot", "rb");
#else
    FILE* file = fopen("C4-1.wasm", "rb");
#endif
    if (!file) {
        printf("> Error loading module!\n");
        return 1;
    }

    int ret = fseek(file, 0L, SEEK_END);
    if (ret == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    long file_size = ftell(file);
    if (file_size == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    ret = fseek(file, 0L, SEEK_SET);
    if (ret == -1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }

    wasm_byte_vec_t binary;
    wasm_byte_vec_new_uninitialized(&binary, file_size);
    if (fread(binary.data, file_size, 1, file) != 1) {
        printf("> Error loading module!\n");
        fclose(file);
        return 1;
    }
    fclose(file);

    // Compile.
    // printf("Compiling module...\n");
    own wasm_module_t* module = wasm_module_new(store, &binary);
    if (!module) {
        printf("> Error compiling module!\n");
        return 1;
    }

    wasm_byte_vec_delete(&binary);

    // Create external print functions.
    // printf("Creating callback...\n");
    own wasm_functype_t* func1_type = wasm_functype_new_2_0(wasm_valtype_new_i32(), wasm_valtype_new_i32());
    own wasm_func_t* func1 = wasm_func_new(store, func1_type, assert_eq_i32);

    own wasm_functype_t* func2_type = wasm_functype_new_2_0(wasm_valtype_new_i64(), wasm_valtype_new_i64());
    own wasm_func_t* func2 = wasm_func_new(store, func2_type, assert_eq_i64);

    own wasm_functype_t* func3_type = wasm_functype_new_2_0(wasm_valtype_new_f32(), wasm_valtype_new_f32());
    own wasm_func_t* func3 = wasm_func_new(store, func3_type, assert_eq_f32);

    own wasm_functype_t* func4_type = wasm_functype_new_2_0(wasm_valtype_new_f64(), wasm_valtype_new_f64());
    own wasm_func_t* func4 = wasm_func_new(store, func4_type, assert_eq_f64);

    wasm_functype_delete(func1_type);
    wasm_functype_delete(func2_type);
    wasm_functype_delete(func3_type);
    wasm_functype_delete(func4_type);

    // Instantiate.
    // printf("Instantiating module...\n");
    wasm_extern_t* externs[] = {
        wasm_func_as_extern(func1),wasm_func_as_extern(func2),wasm_func_as_extern(func3), wasm_func_as_extern(func4)
    };


    wasm_extern_vec_t imports = WASM_ARRAY_VEC(externs);
//    own wasm_instance_t* instance =
//        wasm_instance_new(store, module, &imports, NULL);
    own wasm_instance_t* instance =
        wasm_instance_new_with_args(store, module, &imports, NULL, 32768, 0);
    if (!instance) {
        printf("> Error instantiating module!\n");
        return 1;
    }


    // printf("Extracting export...\n");
    own wasm_extern_vec_t exports;
    wasm_instance_exports(instance, &exports);
    if (exports.size == 0) {
        printf("> Error accessing exports!\n");
        return 1;
    }else{
        //printf("Export size : %zu\n", exports.size);
    }

    // printf("Calling func1...\n");
    const wasm_func_t* func = wasm_extern_as_func(exports.data[0]);
    if (func == NULL) {
        printf("> Error accessing export!\n");
        return 1;
    }

    wasm_val_t args = WASM_EMPTY_VEC;
    wasm_val_t results = WASM_EMPTY_VEC;
    wasm_func_call(func, &args, &results);

    wasm_func_delete(func1);
    wasm_func_delete(func2);
    wasm_func_delete(func3);
    wasm_func_delete(func4);


    // Shut down.
    // printf("Shutting down...\n");
    wasm_store_delete(store);
    wasm_engine_delete(engine);

    // All done.
    // printf("Done.\n");
    return 0;
}