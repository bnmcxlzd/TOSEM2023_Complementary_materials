
#include <stdio.h>
#include <string.h>
#include <wasmedge/wasmedge.h>


WasmEdge_Result assert_eq_i32_host(void *Data, WasmEdge_MemoryInstanceContext *MemCxt,
                                   const WasmEdge_Value *In, WasmEdge_Value *Out) {
  int32_t Val1 = WasmEdge_ValueGetI32(In[0]);
  int32_t Val2 = WasmEdge_ValueGetI32(In[1]);

  if(Val1 == Val2){
    printf("equals i32 !\n");
  }else{
    printf("Not equals i32 !\n");
  }

  return WasmEdge_Result_Success;
}

WasmEdge_Result assert_eq_i64_host(void *Data, WasmEdge_MemoryInstanceContext *MemCxt,
                                   const WasmEdge_Value *In, WasmEdge_Value *Out) {
  int64_t Val1 = WasmEdge_ValueGetI64(In[0]);
  int64_t Val2 = WasmEdge_ValueGetI64(In[1]);

  if(Val1 == Val2){
  printf("equals i64 !\n");
  }else{
  printf("Not equals i64 !\n");
  }

  return WasmEdge_Result_Success;
}

WasmEdge_Result assert_eq_f32_host(void *Data, WasmEdge_MemoryInstanceContext *MemCxt,
                                   const WasmEdge_Value *In, WasmEdge_Value *Out) {
  float Val1 = WasmEdge_ValueGetF32(In[0]);
  float Val2 = WasmEdge_ValueGetF32(In[1]);

  if(Val1 == Val2){
  printf("equals f32 !\n");
  }else{
  printf("Not equals f32 !\n");
  }

  return WasmEdge_Result_Success;
}

WasmEdge_Result assert_eq_f64_host(void *Data, WasmEdge_MemoryInstanceContext *MemCxt,
                                   const WasmEdge_Value *In, WasmEdge_Value *Out) {
  float Val1 = WasmEdge_ValueGetF64(In[0]);
  float Val2 = WasmEdge_ValueGetF64(In[1]);

  if(Val1 == Val2){
  printf("equals f64 !\n");
  }else{
  printf("Not equals f64 !\n");
  }

  return WasmEdge_Result_Success;
}


int main() {
  /* Create the configure context and add the WASI support. */
  /* This step is not necessary unless you need WASI support. */
  WasmEdge_ConfigureContext *ConfCxt = WasmEdge_ConfigureCreate();
  WasmEdge_ConfigureAddHostRegistration(ConfCxt, WasmEdge_HostRegistration_Wasi);

  /* The configure and store context to the VM creation can be NULL. */
  WasmEdge_VMContext *VMCxt = WasmEdge_VMCreate(ConfCxt, NULL);


  /* Create the import object. */
  WasmEdge_String importName = WasmEdge_StringCreateByCString("env");
  WasmEdge_ImportObjectContext *ImpObj = WasmEdge_ImportObjectCreate(importName);
  WasmEdge_StringDelete(importName);

  // import host functions
  //i32
  enum WasmEdge_ValType Param1[2];
  Param1[0] = WasmEdge_ValType_I32;
  Param1[1] = WasmEdge_ValType_I32;
  WasmEdge_FunctionTypeContext *HostFType1 = NULL;
  HostFType1 = WasmEdge_FunctionTypeCreate(Param1, 2, NULL, 0);
  WasmEdge_FunctionInstanceContext *HostFunc1 = WasmEdge_FunctionInstanceCreate(HostFType1, assert_eq_i32_host, NULL, 0);
  WasmEdge_FunctionTypeDelete(HostFType1);

  WasmEdge_String FuncName1 = WasmEdge_StringCreateByCString("assert_eq_i32");
  WasmEdge_ImportObjectAddFunction(ImpObj, FuncName1, HostFunc1);
  WasmEdge_StringDelete(FuncName1);

  //i64
  enum WasmEdge_ValType Param2[2];
  Param2[0] = WasmEdge_ValType_I64;
  Param2[1] = WasmEdge_ValType_I64;
  WasmEdge_FunctionTypeContext *HostFType2 = NULL;
  HostFType2 = WasmEdge_FunctionTypeCreate(Param2, 2, NULL, 0);
  WasmEdge_FunctionInstanceContext *HostFunc2 = WasmEdge_FunctionInstanceCreate(HostFType2, assert_eq_i64_host, NULL, 0);
  WasmEdge_FunctionTypeDelete(HostFType2);

  WasmEdge_String FuncName2 = WasmEdge_StringCreateByCString("assert_eq_i64");
  WasmEdge_ImportObjectAddFunction(ImpObj, FuncName2, HostFunc2);
  WasmEdge_StringDelete(FuncName2);

  //f32
  enum WasmEdge_ValType Param3[2];
  Param3[0] = WasmEdge_ValType_F32;
  Param3[1] = WasmEdge_ValType_F32;
  WasmEdge_FunctionTypeContext *HostFType3 = NULL;
  HostFType3 = WasmEdge_FunctionTypeCreate(Param3, 2, NULL, 0);
  WasmEdge_FunctionInstanceContext *HostFunc3 = WasmEdge_FunctionInstanceCreate(HostFType3, assert_eq_f32_host, NULL, 0);
  WasmEdge_FunctionTypeDelete(HostFType3);

  WasmEdge_String FuncName3 = WasmEdge_StringCreateByCString("assert_eq_f32");
  WasmEdge_ImportObjectAddFunction(ImpObj, FuncName3, HostFunc3);
  WasmEdge_StringDelete(FuncName3);

  //f64
  enum WasmEdge_ValType Param4[2];
  Param4[0] = WasmEdge_ValType_F64;
  Param4[1] = WasmEdge_ValType_F64;
  WasmEdge_FunctionTypeContext *HostFType4 = NULL;
  HostFType4 = WasmEdge_FunctionTypeCreate(Param4, 2, NULL, 0);
  WasmEdge_FunctionInstanceContext *HostFunc4 = WasmEdge_FunctionInstanceCreate(HostFType4, assert_eq_f64_host, NULL, 0);
  WasmEdge_FunctionTypeDelete(HostFType4);

  WasmEdge_String FuncName4 = WasmEdge_StringCreateByCString("assert_eq_f64");
  WasmEdge_ImportObjectAddFunction(ImpObj, FuncName4, HostFunc4);
  WasmEdge_StringDelete(FuncName4);


  WasmEdge_VMRegisterModuleFromImport(VMCxt, ImpObj);

  /* Function name. */
  WasmEdge_String FuncName = WasmEdge_StringCreateByCString("func2");

  /* Run the WASM function from file. */
  WasmEdge_Result Res = WasmEdge_VMRunWasmFromFile(VMCxt, "C4-1-memory_test.wasm", FuncName, NULL, 0, NULL, 0);

  if (WasmEdge_ResultOK(Res)) {
    printf("Successfully executed !");
  } else {
    printf("Error !");
  }

  /* Resources deallocations. */
  WasmEdge_FunctionInstanceDelete(HostFunc1);
  WasmEdge_FunctionInstanceDelete(HostFunc2);
  WasmEdge_FunctionInstanceDelete(HostFunc3);
  WasmEdge_FunctionInstanceDelete(HostFunc4);
  WasmEdge_VMDelete(VMCxt);
  WasmEdge_ConfigureDelete(ConfCxt);
  WasmEdge_StringDelete(FuncName);
  return 0;
}
