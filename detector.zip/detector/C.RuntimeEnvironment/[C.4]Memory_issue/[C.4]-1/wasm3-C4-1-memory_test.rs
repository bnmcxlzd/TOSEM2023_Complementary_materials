// cargo run --example C4-1-memory_test

use wasm3::{Environment, WasmArg};
use wasm3::Module;

fn main() {
    println!("Start testing ...");

    let env = Environment::new().expect("Unable to create environment");
    let rt = env
        .create_runtime(1024 * 60)
        .expect("Unable to create runtime");
    let module = Module::parse(&env, &include_bytes!("../../taxonomy/RuntimeEnvironment/C4-1-memory_test.wasm")[..])
        .expect("Unable to parse module");
    let mut module = rt.load_module(module).expect("Unable to load module");


    module
        .link_function::<(i32, i32), ()>("env", "assert_eq_i32", assert_hosti32)
        .expect("Unable to link function");
    module
        .link_function::<(i64, i64), ()>("env", "assert_eq_i64", assert_hosti64)
        .expect("Unable to link function");
    module
        .link_function::<(f32, f32), ()>("env", "assert_eq_f32", assert_hostf32)
        .expect("Unable to link function");
    module
        .link_function::<(f64, f64), ()>("env", "assert_eq_f64", assert_hostf64)
        .expect("Unable to link function");



    let func = module
        .find_function::<(), ()>("func2")
        .expect("Unable to find function");
    func.call();

    // println!("{}ms in seconds is {:?}s.", MILLIS, func.call());
    // assert_eq!(func.call(), Ok(MILLIS / 1000));

    println!("Finish testing ...");
}



wasm3::make_func_wrapper!(assert_hosti32: myasserti32(x:u32, y:u32));
fn myasserti32(x:u32, y:u32){
    if(x == y){
        println!("equals i32 !");
    }else{
        println!("Not equals i32 !");
    }
}

wasm3::make_func_wrapper!(assert_hosti64: myasserti64(x:u64, y:u64));
fn myasserti64(x:u64, y:u64){
    if(x == y){
        println!("equals i64 !");
    }else{
        println!("Not equals i64 !");
    }
}

wasm3::make_func_wrapper!(assert_hostf32: myassertf32(x:f32, y:f32));
fn myassertf32(x:f32, y:f32){
    if(x == y){
        println!("equals f32 !");
    }else{
        println!("Not equals f32 !");
    }
}

wasm3::make_func_wrapper!(assert_hostf64: myassertf64(x:f64, y:f64));
fn myassertf64(x:f64, y:f64){
    if(x == y){
        println!("equals f64 !");
    }else{
        println!("Not equals f64 !");
    }
}