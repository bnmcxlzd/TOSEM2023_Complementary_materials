//! This is a simple example introducing the core concepts of the Wasmer API.
//!
//! You can run the example directly by executing the following in the Wasmer root:
//!
//! ```shell
//! cargo run --example test-C4-1 --release --features "singlepass,cranelift,llvm,wasi"
//! ```

use wasmer::{imports, wat2wasm, Function, Instance, Module, NativeFunc, Store, Value};

// compiler
use wasmer_compiler_cranelift::Cranelift;
use wasmer_compiler_singlepass::Singlepass;
use wasmer_compiler_llvm::LLVM;

// engine
use wasmer_engine_universal::Universal;

use std::fs::File;
use std::io::Read;

fn main() -> anyhow::Result<()> {
    let mut f = File::open("benchmark/taxonomy/RuntimeEnvironment/C4-1.wat").unwrap();
    let mut buf = Vec::new();
    f.read_to_end(&mut buf).unwrap();
    let wasm_bytes = wat2wasm(buf.as_slice()).unwrap();
    let store = Store::new(&Universal::new(LLVM::default()).engine());

    println!("Compiling module...");
    // Let's compile the Wasm module.
    let module = Module::new(&store, wasm_bytes)?;


    fn assert_eq_i32_host(x:i32, y:i32){
        if(x == y){
            println!("equals i32 !");
        }else{
            println!("Not equals i32 !");
        }
    }

    fn assert_eq_i64_host(x:i64, y:i64){
        if(x == y){
            println!("equals i64 !");
        }else{
            println!("Not equals i64 !");
        }
    }

    fn assert_eq_f32_host(x:f32, y:f32){
        if(x == y){
            println!("equals f32 !");
        }else{
            println!("Not equals f32 !");
        }
    }

    fn assert_eq_f64_host(x:f64, y:f64){
        if(x == y){
            println!("equals f64 !");
        }else{
            println!("Not equals f64 !");
        }
    }


    let import_object = imports! {
        // We use the default namespace "env".
        "env" => {
            // And call our function "say_hello".
            "assert_eq_i32" => Function::new_native(&store, assert_eq_i32_host),
            "assert_eq_i64" => Function::new_native(&store, assert_eq_i64_host),
            "assert_eq_f32" => Function::new_native(&store, assert_eq_f32_host),
            "assert_eq_f64" => Function::new_native(&store, assert_eq_f64_host),
        },
    };


    let instance = Instance::new(&module, &import_object)?; //有start部分，load instance之后会自动执行start

    let func1 = instance.exports.get_function("func1")?;
    func1.call(&[])?;
    // let func2 = instance.exports.get_function("func2")?;
    // func2.call(&[])?;

    Ok(())
}

#[test]
fn test_hello_world() -> anyhow::Result<()> {
    main()
}
