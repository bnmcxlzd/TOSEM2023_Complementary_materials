package main

import (
	"fmt"
	"github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {
    wasmBytes, _ := ioutil.ReadFile("./C4-1-memory_test.wasm")

    engine := wasmer.NewEngine()
    store := wasmer.NewStore(engine)

    // Compiles the module
    module, err := wasmer.NewModule(store, wasmBytes)

    if err != nil {
        fmt.Println("Failed to compile module:", err)
    }

	fmt.Println("Creating the imported function...")
	
    assert_eq_i32 := wasmer.NewFunction(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.I32, wasmer.I32), wasmer.NewValueTypes()),
		func(args []wasmer.Value) ([]wasmer.Value, error) {
            if args[0].I32() == args[1].I32(){
                fmt.Println("equals i32 !")
            }else{
                fmt.Println("Not equals i32 !")
            }
			return []wasmer.Value{}, nil
		},
	)

    assert_eq_f32 := wasmer.NewFunction(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.F32, wasmer.F32), wasmer.NewValueTypes()),
		func(args []wasmer.Value) ([]wasmer.Value, error) {
            if args[0].F32() == args[1].F32(){
                fmt.Println("equals f32 !")
            }else{
                fmt.Println("Not equals f32 !")
            }
			return []wasmer.Value{}, nil
		},
	)

    assert_eq_i64 := wasmer.NewFunction(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.I64, wasmer.I64), wasmer.NewValueTypes()),
		func(args []wasmer.Value) ([]wasmer.Value, error) {
            if args[0].I64() == args[1].I64(){
                fmt.Println("equals i64 !")
            }else{
                fmt.Println("Not equals i64 !")
            }
			return []wasmer.Value{}, nil
		},
	)

    assert_eq_f64 := wasmer.NewFunction(
		store,
		wasmer.NewFunctionType(wasmer.NewValueTypes(wasmer.F64, wasmer.F64), wasmer.NewValueTypes()),
		func(args []wasmer.Value) ([]wasmer.Value, error) {
            if args[0].F64() == args[1].F64(){
                fmt.Println("equals f64 !")
            }else{
                fmt.Println("Not equals f64 !")
            }
			return []wasmer.Value{}, nil
		},
	)

    // Instantiates the module
    importObject := wasmer.NewImportObject()
    importObject.Register(
		"env",
		map[string]wasmer.IntoExtern{
			"assert_eq_i32": assert_eq_i32,
            "assert_eq_f32": assert_eq_f32,
            "assert_eq_i64": assert_eq_i64,
            "assert_eq_f64": assert_eq_f64,
		},
	)

    instance, err := wasmer.NewInstance(module, importObject)

    if err != nil {
        panic(fmt.Sprintln("Failed to instantiate the module:", err))
    }
    

    func1, err := instance.Exports.GetFunction("func2")
    if err != nil {
	    panic(fmt.Sprintln("Failed to get the `func2` function:", err))
    }

    result, err := func1()

    if err != nil {
        panic(fmt.Sprintln("Failed to call the `func2` function:", err))
    }
    
    fmt.Println(result)
}