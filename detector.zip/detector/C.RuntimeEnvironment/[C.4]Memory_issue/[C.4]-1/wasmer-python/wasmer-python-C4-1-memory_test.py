import os
from wasmer import engine, wat2wasm, Store, Module, ImportObject, Function, FunctionType, Type, Instance
from wasmer_compiler_cranelift import Compiler


# Create a store.
store = Store(engine.Universal(Compiler))

# Let's compile the Wasm module.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../C4-1-memory_test.wasm', 'rb').read())



import_object = ImportObject()

# Let's write the Python function that is going to be imported,
# i.e. called by the WebAssembly module.
def assert_eq_i32(x: int, y:int):
    if x == y:
        print("equals i32 !")
    else:
        print("Not equals i32 !")

def assert_eq_f32(x: float, y:float):
    if x == y:
        print("equals f32 !")
    else:
        print("Not equals f32 !")

def assert_eq_i64(x: int, y:int):
    if x == y:
        print("equals i64 !")
    else:
        print("Not equals i64 !")

def assert_eq_f64(x: float, y:float):
    if x == y:
        print("equals f64 !")
    else:
        print("Not equals f64 !")

assert_eq_i32_host = Function(store, assert_eq_i32)
assert_eq_f32_host = Function(store, assert_eq_f32)
assert_eq_i64_host = Function(store, assert_eq_i64)
assert_eq_f64_host = Function(store, assert_eq_f64)


def assert_eq_i32(x, y):
    if x == y:
        print("equals i32 !")
    else:
        print("Not equals i32 !")

def assert_eq_f32(x, y):
    if x == y:
        print("equals f32 !")
    else:
        print("Not equals f32 !")

def assert_eq_i64(x, y):
    if x == y:
        print("equals i64 !")
    else:
        print("Not equals i64 !")

def assert_eq_f64(x, y):
    if x == y:
        print("equals f64 !")
    else:
        print("Not equals f64 !")

assert_eq_i32_host = Function(
    store,
    assert_eq_i32,
    FunctionType([Type.I32, Type.I32], [])
)

assert_eq_f32_host = Function(
    store,
    assert_eq_f32,
    FunctionType([Type.F32, Type.F32], [])
)

assert_eq_i64_host = Function(
    store,
    assert_eq_i64,
    FunctionType([Type.I64, Type.I64], [])
)

assert_eq_f64_host = Function(
    store,
    assert_eq_f64,
    FunctionType([Type.F64, Type.F64], [])
)


import_object.register(
    "env",
    {
        "assert_eq_i32": assert_eq_i32_host,
        "assert_eq_f32": assert_eq_f32_host,
        "assert_eq_i64": assert_eq_i64_host,
        "assert_eq_f64": assert_eq_f64_host,
    }
)

# Let's instantiate the module!
instance = Instance(module, import_object)


func1 = instance.exports.func2
results = func1()

print(results)