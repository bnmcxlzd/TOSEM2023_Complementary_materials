//! Small example of how to instantiate a wasm module that imports one function,
//! showing how you can fill in host functionality for a wasm module.

// cargo run -q --example test-C4-1

use anyhow::Result;
use wasmtime::*;


fn main() -> Result<()> {
    // Modules can be compiled through either the text or binary format
    let engine = Engine::default();
    let module = Module::from_file(&engine, "./C4-1.wat")?;

    // let module;
    // unsafe{
    //     module = Module::deserialize(&engine, "benchmark/taxonomy/RuntimeEnvironment/C4-1.cwasm")?;
    // }



    let mut linker = Linker::new(&engine);
    linker.func_wrap("env", "assert_eq_i32", |caller: Caller<'_, u32>, x: i32, y: i32| {
        if(x == y){
            println!("equals i32 !");
        }else{
            println!("Not equals i32 !");
        }
    })?;
    linker.func_wrap("env", "assert_eq_i64", |caller: Caller<'_, u32>, x: i64, y: i64| {
        if(x == y){
            println!("equals i64 !");
        }else{
            println!("Not equals i64 !");
        }
    })?;
    linker.func_wrap("env", "assert_eq_f32", |caller: Caller<'_, u32>, x: f32, y: f32| {
        if(x == y){
            println!("equals f32 !");
        }else{
            println!("Not equals f32 !");
        }
    })?;
    linker.func_wrap("env", "assert_eq_f64", |caller: Caller<'_, u32>, x: f64, y: f64| {
        if(x == y){
            println!("equals f64 !");
        }else{
            println!("Not equals f64 !");
        }
    })?;


    let mut store = Store::new(&engine, 4);
    let instance = linker.instantiate(&mut store, &module)?;

    println!("Extracting export...");
    let func1 = instance.get_typed_func::<(), (), _>(&mut store, "func1")?;

    println!("Calling func1...");
    func1.call(&mut store, ())?;

    Ok(())
}

