# [C.5]-1

## Test target
This test case is to test whether a wasm runtime could report the execution of an unreachable.
It means that whether a Wasm runtime could successfully deal with the `unreachable` instruction and get the information.

## Steps to use
Use cli or high-level language api to load the module and execute the `start` function.

## Expected output
Successfully find information and report the execution of an unreachable.
error: failed to run `C5-1.wasm`
│   1: RuntimeError: unreachable
           at <unnamed> (C5-1.wasm[0]:0x1a)
╰─▶ 2: unreachable
