package main

import (
	"fmt"
	"github.com/wasmerio/wasmer-go/wasmer"
	"io/ioutil"
)

func main() {
    wasmBytes, _ := ioutil.ReadFile("./C5-1.wasm")

    engine := wasmer.NewEngine()
    store := wasmer.NewStore(engine)

    // Compiles the module
    module, err := wasmer.NewModule(store, wasmBytes)

    if err != nil {
        fmt.Println("Failed to compile module:", err)
    }

    // Instantiates the module
    importObject := wasmer.NewImportObject()
    instance, err := wasmer.NewInstance(module, importObject)

    if err != nil {
        panic(fmt.Sprintln("Failed to instantiate the module:", err))
    }

    // Gets the `sum` exported function from the WebAssembly instance.

    func1, err := instance.Exports.GetFunction("start")
    if err != nil {
	    panic(fmt.Sprintln("Failed to get the `start` function:", err))
    }

    result, err := func1()

    if err != nil {
        panic(fmt.Sprintln("Failed to call the `start` function:", err))
    }
    
    fmt.Println(result)
}