import os
from wasmer import engine, wat2wasm, Store, Module, ImportObject, Function, FunctionType, Type, Instance
from wasmer_compiler_cranelift import Compiler


# Create a store.
store = Store(engine.Universal(Compiler))

# Let's compile the Wasm module.
__dir__ = os.path.dirname(os.path.realpath(__file__))
module = Module(Store(), open(__dir__ + '/../C5-1.wasm', 'rb').read())



# Let's instantiate the module!
instance = Instance(module)

# func1 = instance.exports.func1
# results = func1()

# print(results)