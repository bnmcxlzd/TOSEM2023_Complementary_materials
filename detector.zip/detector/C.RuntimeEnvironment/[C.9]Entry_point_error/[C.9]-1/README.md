# [C.9]-1

## Test target
This test case is to test whether a wasm runtime print error message and successfully execute the wasm file with assigning the function `fib`.

## Steps to use
(1)Use cli or high-level language api to load and execute the module without assigning the function `fib`.
(2)Use cli or high-level language api to load and execute the module with assigning the function `fib`.

## Expected output
(1)Remind to assign the entrypoint
(2)If input `45` as the parameter to function `fib`, the result must be 1134903170