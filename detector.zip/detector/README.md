# README
The result.xlsx shows the detecting result of each test case in the seven WASM runtimes: wasmtime, wasmer, WAMR, wasm3, WasmEdge, wasmer-python and wasmer-go.
The table shows ✅ to indicate the runtime passed the test case. The table shows ❎ to mean the runtime failed to pass the test case. The table shows / to mean the runtime does not support the features in the test case. 

## wasmer
version 2.3.0

(1) compile

```
wasmer --singlepass compile xxx.wasm -o xxx.wasmu
wasmer --llvm compile xxx.wasm -o xxx.wasmu
wasmer --cranelift compile xxx.wasm -o xxx.wasmu
```

execute the compiled file :
```
wasmer xxx.wasmu
```

(2) execute the default 

```
wasmer xxx.wasm
```

(3) execute the function named "func1"

```
wasmer xxx.wat -i func1
```




## wasmtime

(1) compile

```
wasmtime xxx.wasm
```

execute the compiled file :
```
wasmtime run --allow-precompiled xxx.cwasm
```

(2) execute the default 

```
wasmtime run xxx.wasm
```

(3) execute the function named "func1"
```
wasmtime run --invoke 'func1' xxx.wasm
```



## WAMR
version WAMR-05-18-2022

(1) compile

```
wamrc -o xxx.aot xxx.wasm   
```

execute the compiled file :
```
iwasm -f func1 xxx.aot
```

(2) execute the default 

```
iwasm xxx.wasm
```

(3) execute the function named "func1"
```
iwasm -f func1 xxx.wasm
```



## wasm3
(1) execute the default 

```
wasm3 xxx.wasm
```

(2) execute the function named "func1"
```
wasm3 --funnc func1 xxx.wasm
```

## WasmEdge
version 0.9.1

(1) compile

```
wasmedgec xxx.wasm xxx.so
```

execute the compiled file :
```
wasmedge xxx.so

```

(2) execute the default 

```
wasmedge xxx.wasm
```

(3) execute the function named "func1"
```
wasmedge --reactor --enable-all xxx.wasm func1
```

## wasmer-python
version 1.1.0

## wasmer-go
version 1.0.4
