# README
This table contains all the issues we analyzed with the links, bug categories, and fix categories.